<form action="abonne_detail.php" method="GET">
    <div>
        <label for="idabonne">idAbonne :</label>
        <input type="text" id="idabonne" name="idabonne">
    </div>
    
    <input type="submit" value="Submit" />
</form>