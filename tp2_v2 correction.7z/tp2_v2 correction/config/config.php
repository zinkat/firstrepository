<?php
// Choix de l'environement (pensez à choisir le bon)
// define("ENV", "DEV"); // environnement de développement
define("ENV", "TEST"); // environnement de test
// define("ENV", "PROD"); // environnement de production



?>