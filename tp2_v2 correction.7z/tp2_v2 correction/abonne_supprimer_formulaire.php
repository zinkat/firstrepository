<form action="abonne_supprimer.php" method="GET">
    <div>
        <label for="idabonne">idAbonne :</label>
        <input type="text" id="idabonne" name="idabonne">
    </div>
    
    <input type="submit" value="Submit" />
</form>