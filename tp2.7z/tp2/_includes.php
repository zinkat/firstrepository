<?php
include_once("config/config.php");
include_once("config/load_configuration.php");
include_once("langues/load_langue.php");
include_once("classes/db.php"); // classe
